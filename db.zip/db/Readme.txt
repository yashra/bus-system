Instruction
1.Install xampp app in your root directory.
2.Start mysql and apache in control panel as shown in screen 1.
3.Now open your browser and write the address given in screen 2.
4.Fill the necessary fields as per screen 3.
5.If the password and confirm password are correct the screen 4 will appear.
6.After then open another tab with link as per given in screen 5.
7.Click the testing database at left of your window as shown in screen 6.
8.Atlast you will see the data in table as you have entered in text field like screen 7.
9.Exit.
